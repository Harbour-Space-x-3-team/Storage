*Algoritmo para encontrar el minimo ciclo
*Estructura para Segment Tree (all)
*Li chao tree segmentos
*Make template of palindromes frequency
*Hacer algun dia MST invertido
*Study Slope Trick
