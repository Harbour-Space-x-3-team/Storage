freopen("work/tc.txt", "r", stdin);
freopen("work/ans2.txt", "w", stdout);
