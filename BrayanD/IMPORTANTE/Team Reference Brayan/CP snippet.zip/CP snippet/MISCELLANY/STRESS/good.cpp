freopen("work/tc.txt", "r", stdin);
freopen("work/ans1.txt", "w", stdout);
